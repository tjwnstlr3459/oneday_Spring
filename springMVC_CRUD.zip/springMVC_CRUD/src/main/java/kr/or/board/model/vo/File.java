package kr.or.board.model.vo;

import lombok.Data;

@Data
public class File {
	private int fileNo;
	private String fileName;
	private String filePath;
	private int boardNo;
}
